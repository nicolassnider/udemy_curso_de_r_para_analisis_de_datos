# primera clase

# instalar paquete de datos (requiere internet)
# install.packages('gapminder')
# install.packages('tidyverse')

# cargar paquete de datos


# cargar paquete de analisis


# cargar datos


# ver encabezado de datos


# generando preguntas

# para que años está la información


# para que paises está la información

# mostrar todas las columnas


# como se ve la esperanza de vida en 2007 para Portugal


# pregunta: esperanza de vida España 2007

# ahora una grafica


# Pregunta: qué pais tiene MINIMA EDV en 2007 en Europa


# ejercicio como es la esperanza de vida en tu pais


